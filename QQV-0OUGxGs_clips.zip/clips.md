# Whatever You Steal in GTA 6, You Keep!
Source: https://youtu.be/QQV-0OUGxGs?si=gaCN8-RXwvEvVhEy

1. **Every Dollar Goes to Mom** `00:00:00-00:00:09` (3.45 MB) - Strong opener: 'Every dollar Tareq steals in GTA VI, I will give his mom in REAL life. Take off your blindfold. Whaat?! Here's a controller. Ohh my God. The one hour timer just started. GOOD luck!!' — a self-contained premise hook in the first seconds.
2. **Jewelry Store Heist** `00:02:11-00:02:47` (3.95 MB) - Action beat: 'Get down, get DOWN!... $1,000!... $5,000 worth of jewelry... This is probably the biggest lift of my LIFE!' — ends on the payoff.
3. **Went South Instead of North** `00:04:16-00:04:28` (5.89 MB) - Funny map mixup: 'You STARTED me on this part of the map. Yeah, I started you up there... and then you went SOUTH instead of northhh!'
4. **Mom Was in a Main Channel Video** `00:04:46-00:05:05` (5.04 MB) - Story with payoff: 'So Tareq's mom was in a main channel video five years ago. Here's a photo of her... Yeah, I'm glad you shaved the goatee. Good call... Do a bank, if you can.'
5. **I Lost Everything — Bring It On!** `00:06:53-00:07:13` (4.02 MB) - Elevated stakes: 'They're beating me up. You just lost everything. You know what? Jimmy?? Everybody loves a comeback story.'
6. **35 Grand Turned to 135?** `00:14:50-00:15:40` (8.64 MB) - Tension: 'You're at 35 grand for your mom... This is a CRITICAL decision you have to make! ... All right, we're doing it. You're doing it??! I'm doing it. We're DOING IT!!'
7. **Can I Get on the Plane?** `00:16:58-00:17:52` (3.55 MB) - Comedic desperation: 'NoOOoO! That person HATES your mom. NOT THE VAN! WHY?! ... Get in, GET INNNN!'
8. **Mom Wins $44,000** `00:20:36-00:21:25` (2.86 MB) - Climax: 'Tareq, you did it!! Forty-four THOUSAND! Brooo, my mom's gonna FREAK OUT! Hey, mom, I just won you $44,000 in a challenge. You are the BEST SON EVER. ... I love you.'